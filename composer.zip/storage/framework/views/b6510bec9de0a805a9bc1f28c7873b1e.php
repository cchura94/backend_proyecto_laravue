<table>
    <thead>
    <tr >
        <th style="background-color: green;">NOMBRE</th>
        <th>PRECIO</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($prod->nombre); ?></td>
            <td><?php echo e($prod->precio); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\cursos\claravue\backend_proyecto_laravue\resources\views/exports/productos.blade.php ENDPATH**/ ?>