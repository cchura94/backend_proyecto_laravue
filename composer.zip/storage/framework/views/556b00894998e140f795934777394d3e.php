<?php echo e($slot); ?>

<?php /**PATH D:\cursos\claravue\backend_proyecto_laravue\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>