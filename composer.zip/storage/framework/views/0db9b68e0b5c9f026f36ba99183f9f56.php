<style>
    .container{
        width: 80%;
        margin: 0 auto;
    }
    .header{
        text-align: center;
        margin: 0 auto;
    }
    .info{
        margin-bottom: 20px;
    }
    .info p {
        margin: 5px 0;
    }
    .table {
        width: 100%;
        border-collapse: collapse;
    }
    .table th, .table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }
    .table th {
        background-color: #f3f3f3;
    }
</style>
<div class="container">
    <div class="header">
        <h1>Recibo de Pedido</h1>
    </div>
    <div class="info">
        <p><strong>ID Pedido: </strong><?php echo e($pedido->id); ?></p>
        <p><strong>Fecha de Pedido: </strong><?php echo e($pedido->fecha_pedido); ?></p>
        <p><strong>CLIENTE: </strong><?php echo e($pedido->cliente->razon_social); ?></p>
        <p><strong>Correo Cliente: </strong><?php echo e($pedido->cliente->correo); ?></p>
        <p><strong>Vendedor: </strong><?php echo e($pedido->user?$pedido->user->name:''); ?></p>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>Codigo producto</th>
                <th>Nombre</th>
                <th>Precio</th>
                <th>cantidad</th>
                <th>SubTotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pedido->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($producto->id); ?></td>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e(number_format($producto->precio, 2)); ?></td>
                <td><?php echo e($producto->pivot->cantidad); ?></td>
                <td><?php echo e(number_format($producto->precio * $producto->pivot->cantidad, 2)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

</div><?php /**PATH D:\cursos\claravue\backend_proyecto_laravue\resources\views/pdf/recibo.blade.php ENDPATH**/ ?>